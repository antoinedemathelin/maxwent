from setuptools import setup, find_packages

setup(
    name="maxwent",
    version="0.1.0",
    description="Maximum Weight Entropy",
    author="Antoine de Mathelin",
    author_email="antoine.demat@gmail.com",
    packages=find_packages(),
    install_requires=[],  # List any dependencies here
)